from urllib.request import Request, urlopen
from urllib.request import HTTPError
from bs4 import BeautifulSoup
import re
import sys
import pymysql

conn=pymysql.connect(host='designduck.cphno6qganog.ap-northeast-2.rds.amazonaws.com',user='designduck',passwd='designduck',db='mysql',charset='utf8')
cur=conn.cursor()
cur.execute("USE scraping")
algopaList=["ctk0327","fluxus","morot2","drcobi","dragon4499","oyrin9595 ","ggrn","klee"]


def lambda_handler(event, context):
    for member in algopaList:
        storeSolving(member, getSolving(member), getTry(member))
    conn.close()
    return 'Update Solving Problems'


def storeSolving(id, solving, trySolving):
    for problem in solving:
        findNum = cur.execute("SELECT solving FROM solving where userid=%s and problemId=%s", (id, problem))
        if findNum == 0:
            cur.execute("INSERT INTO solving (userId,problemId,solving) VALUES (%s,%s,'PASS')",
                        (id, problem))
        else:
            findSolving = cur.fetchall()[0]
            for raw_data in findSolving:
                if raw_data != 'PASS':
                    cur.execute("Update Solving Set solving='PASS' WHERE userid=%s and problemId=%s", (id, problem))

    for problem in trySolving:
        findNum = cur.execute("SELECT solving FROM solving where userid=%s and problemId=%s", (id, problem))
        if findNum == 0:
            cur.execute("INSERT INTO solving (userId,problemId,solving) VALUES (%s,%s,'FAIL')",
                        (id, problem))
    cur.connection.commit()


def getSolving(member):
    try:
        baseUrl = 'https://www.acmicpc.net/'
        req = Request(baseUrl + '/user/' + member, headers={'User-Agent': 'Mozilla/5.0'})
        webpage = urlopen(req).read()
        bsObj = BeautifulSoup(webpage, "html.parser")
        problemList = bsObj.findAll("div", {"class": "panel-body"})[0].findAll("span", {"style": "display:none;"})
        # print(problemList)
        retunList = [];
        for problem in problemList:
            retunList.append(problem.find("a").attrs['href'].split("/")[2])
            # print(problem.find("a"))

        return retunList;
    except HTTPError as e:
        print(e)


def getTry(member):
    try:
        baseUrl = 'https://www.acmicpc.net/'
        req = Request(baseUrl + '/user/' + member, headers={'User-Agent': 'Mozilla/5.0'})
        webpage = urlopen(req).read()
        bsObj = BeautifulSoup(webpage, "html.parser")
        problemList = bsObj.findAll("div", {"class": "panel-body"})[1].findAll("span", {"style": "display:none;"})
        # print(problemList)
        retunList = [];
        for problem in problemList:
            retunList.append(problem.find("a").attrs['href'].split("/")[2])
            # print(problem.find("a"))

        return retunList;
    except HTTPError as e:
        print(e)


for member in algopaList:
    storeSolving(member, getSolving(member), getTry(member))